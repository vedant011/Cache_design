package com.company.mystorage;

public interface removalalgo {

    Object removeifmemorygetsfull();
}
